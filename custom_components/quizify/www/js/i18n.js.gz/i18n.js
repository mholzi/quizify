/**
 * Quizify Internationalization (i18n) Module
 * Provides translation functionality for all UI text
 */
window.QuizifyI18n = (function() {
    'use strict';

    var currentLanguage = 'en';
    var translations = {};
    var fallbackTranslations = {};
    var isLoaded = false;
    var loadPromise = null;
    var latestLoad = null;

    async function fetchTranslations(langCode) {
        try {
            // Cache-bust via the page's cache-buster query param (set by the
            // server-side template). Without this the browser HTTP cache
            // pins the old JSON across releases, so translation fixes ship
            // but don't surface until users clear cache.
            var bust = '';
            try {
                var anyScript = document.querySelector('script[src*="i18n.js?v="]');
                if (anyScript) {
                    var m = anyScript.src.match(/[?&]v=([^&]+)/);
                    if (m) bust = '?v=' + encodeURIComponent(m[1]);
                }
            } catch (_e) { /* ignore */ }
            var response = await fetch('/quizify/static/i18n/' + langCode + '.json' + bust);
            if (!response.ok) {
                console.warn('[i18n] Failed to load ' + langCode + '.json:', response.status);
                return {};
            }
            return await response.json();
        } catch (err) {
            console.warn('[i18n] Error loading ' + langCode + '.json:', err);
            return {};
        }
    }

    // #1055: a load only installs its bundle if its language is still the
    // one asked for when the bundle arrives. Two loads overlap whenever the
    // game language lands while the page is still fetching the browser's —
    // the host's tab right after the redirect from the admin page, any phone
    // loading the page mid-game. The newer one (English, already held as the
    // fallback) finished first, and the older one then wrote its German
    // bundle over it: getLanguage() said "en", every label said German, and
    // nothing corrected it, because each later game_state saw the language
    // already "matching" and skipped the switch.
    async function loadTranslations() {
        var lang = currentLanguage;
        if (Object.keys(fallbackTranslations).length === 0) {
            var fallback = await fetchTranslations('en');
            if (Object.keys(fallbackTranslations).length === 0) {
                fallbackTranslations = fallback;
            }
        }
        var loaded = (lang === 'en')
            ? fallbackTranslations
            : await fetchTranslations(lang);
        if (lang !== currentLanguage) return;  // superseded while on the wire
        translations = loaded;
        isLoaded = true;
    }

    function getNestedValue(obj, key) {
        if (!obj || !key) return undefined;
        var parts = key.split('.');
        var current = obj;
        for (var i = 0; i < parts.length; i++) {
            if (current === undefined || current === null) return undefined;
            current = current[parts[i]];
        }
        return current;
    }

    function t(key, params) {
        var value = getNestedValue(translations, key);
        if (value === undefined && currentLanguage !== 'en') {
            value = getNestedValue(fallbackTranslations, key);
        }
        if (value === undefined) {
            return key;
        }
        if (params && typeof value === 'string') {
            Object.keys(params).forEach(function(param) {
                value = value.replace(new RegExp('\\{' + param + '\\}', 'g'), params[param]);
            });
        }
        return value;
    }

    function getErrorMessage(code) {
        return t('errors.' + code) || t('errors.UNKNOWN');
    }

    var SUPPORTED_LANGUAGES = ['en', 'de', 'es'];

    async function setLanguage(langCode) {
        if (SUPPORTED_LANGUAGES.indexOf(langCode) === -1) {
            langCode = 'en';
        }
        if (langCode === currentLanguage && isLoaded) return;
        currentLanguage = langCode;
        var mine = latestLoad = loadTranslations();
        await mine;
        // Superseded mid-flight (#1055): resolve only once the language that
        // won is in, so a caller that sweeps the page on resolve — init()'s
        // does — paints from the bundle that is actually active.
        while (latestLoad !== mine) {
            mine = latestLoad;
            await mine;
        }
    }

    function getLanguage() {
        return currentLanguage;
    }

    // #734: a data-i18n key that no bundle carries used to fail in complete
    // silence — t() returns the key, initPageTranslations leaves the element
    // alone, and the English markup ships to a German television. The pill
    // pointed at "dashboard.reconnecting" for months without a single
    // complaint from the code. Say it out loud; the real net is
    // tests/test_television_speaks_the_room_language_733_734.py, which fails
    // the build before it reaches a living room.
    var warnedMissingKeys = {};

    function warnMissingKey(attr, key) {
        if (warnedMissingKeys[key]) return;
        warnedMissingKeys[key] = true;
        console.warn('[i18n] no translation for ' + attr + '="' + key + '" — element left untranslated');
    }

    // #776: a data-i18n key that needs {placeholders} used to be untranslatable
    // by the page sweep — the only way to fill one was a one-off t(key, params)
    // call writing textContent, and a line written that way is frozen in
    // whichever bundle happened to be loaded at that instant (see
    // renderAllTime in player-lobby.js: the phone joined in English, the game
    // language arrived a heartbeat later, and the standing stayed English on a
    // German screen). Carrying the params on the element as JSON lets the sweep
    // re-render the line in the new language with no help from the caller.
    function _readI18nParams(el) {
        var raw = el.getAttribute('data-i18n-params');
        if (!raw) return null;
        try {
            var parsed = JSON.parse(raw);
            return (parsed && typeof parsed === 'object') ? parsed : null;
        } catch (_e) {
            return null;  // malformed attribute: translate without params
        }
    }

    function initPageTranslations(root) {
        var scope = root || document;
        scope.querySelectorAll('[data-i18n]').forEach(function(el) {
            var key = el.getAttribute('data-i18n');
            if (key) {
                var translated = t(key, _readI18nParams(el));
                if (translated !== key) el.textContent = translated;
                else warnMissingKey('data-i18n', key);
            }
        });
        scope.querySelectorAll('[data-i18n-placeholder]').forEach(function(el) {
            var key = el.getAttribute('data-i18n-placeholder');
            if (key) {
                var translated = t(key);
                if (translated !== key) el.placeholder = translated;
                else warnMissingKey('data-i18n-placeholder', key);
            }
        });
        scope.querySelectorAll('[data-i18n-title]').forEach(function(el) {
            var key = el.getAttribute('data-i18n-title');
            if (key) {
                var translated = t(key);
                if (translated !== key) el.title = translated;
                else warnMissingKey('data-i18n-title', key);
            }
        });
        scope.querySelectorAll('[data-i18n-aria-label]').forEach(function(el) {
            var key = el.getAttribute('data-i18n-aria-label');
            if (key) {
                var translated = t(key);
                if (translated !== key) el.setAttribute('aria-label', translated);
                else warnMissingKey('data-i18n-aria-label', key);
            }
        });
        // Sync <html lang> with the active language so screen readers
        // and translation extensions get the correct hint.
        if (document.documentElement && currentLanguage) {
            document.documentElement.lang = currentLanguage;
        }
    }

    function detectBrowserLanguage() {
        var browserLang = navigator.language || navigator.userLanguage || 'en';
        var langLower = browserLang.toLowerCase();
        if (langLower.startsWith('de')) return 'de';
        if (langLower.startsWith('es')) return 'es';
        return 'en';
    }

    // Preferred UI language for HOST screens (launcher, admin, dashboard):
    // Home Assistant's configured language wins, injected server-side into the
    // quizify-ha-lang meta tag. Falls back to browser locale (e.g. standalone
    // dev server where the tag is empty). Without this, host screens flashed
    // English then flipped to the browser language, ignoring the HA setting.
    function getPreferredLanguage() {
        try {
            var meta = document.querySelector('meta[name="quizify-ha-lang"]');
            var haLang = meta ? meta.getAttribute('content') : '';
            // Guard against an unsubstituted {{HA_LANG}} token.
            if (haLang && haLang.indexOf('{') === -1) {
                var hl = haLang.toLowerCase();
                if (hl.indexOf('de') === 0) return 'de';
                if (hl.indexOf('es') === 0) return 'es';
                return 'en';
            }
        } catch (_e) { /* ignore */ }
        return detectBrowserLanguage();
    }

    async function init(langCode) {
        if (loadPromise) return loadPromise;
        var lang = langCode || detectBrowserLanguage();
        loadPromise = setLanguage(lang);
        await loadPromise;
    }

    function isReady() {
        return isLoaded;
    }

    return {
        t: t,
        getErrorMessage: getErrorMessage,
        setLanguage: setLanguage,
        getLanguage: getLanguage,
        initPageTranslations: initPageTranslations,
        detectBrowserLanguage: detectBrowserLanguage,
        getPreferredLanguage: getPreferredLanguage,
        init: init,
        isReady: isReady
    };
})();

window.t = window.QuizifyI18n.t;
